package com.example.examenandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val url = "file:///android_asset/index.html";
        val mivistaWeb: WebView = findViewById(R.id.vistaWeb)
        mivistaWeb.loadUrl(url)
        val ajustesVisorWeb = mivistaWeb.getSettings()
        ajustesVisorWeb.javaScriptEnabled = true
    }
}